#import <CoreLocation/CoreLocation.h>
#import <Flutter/Flutter.h>

@interface FlutterTimezonePlugin : NSObject<FlutterPlugin>
@end
